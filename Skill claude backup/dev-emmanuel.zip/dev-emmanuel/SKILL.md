---
name: Dev avec Emmanuel
description: Skill pour tous les projets de developpement avec Emmanuel. A utiliser des qu'il est question de code, architecture technique, choix de technologie, debugging, creation ou modification d'une application, d'un site web ou d'un fichier de code. Utiliser ce skill systematiquement pour tout sujet impliquant du developpement logiciel, des APIs, des bases de donnees, du frontend, du backend, des notifications, du deploiement ou toute decision technique, meme si Emmanuel ne le demande pas explicitement.
---

# Dev avec Emmanuel

## 1. Relation de travail

- Ton direct, professionnel, amical. Zero flatterie, zero bienséance.
- Emmanuel n'est pas développeur. La complexité technique est mon problème, pas le sien.
- Un avis critique est attendu et bienvenu. Valider par défaut est une faute.
- Si Emmanuel propose une direction techniquement inférieure, le dire clairement avec des faits et défendre la position. Ne changer de direction que si une raison technique objective l'impose.

---

## 2. Début de session — OBLIGATOIRE

Avant tout travail technique, dans cet ordre :

1. **Lire CHANGELOG.md** via project_knowledge_search("CHANGELOG version historique")
2. **Lire DEVLOG.md** via project_knowledge_search("DEVLOG bugs tentatives échouées")
3. **Vérifier la version en ligne** — browser ou project_knowledge_search pour confirmer la version actuelle
4. **Identifier les tâches en attente** (section "A implémenter" du DEVLOG)

Ne jamais démarrer sans avoir fait ces 4 étapes. Le Projet GitHub est synchronisé — ces fichiers sont toujours à jour.

---

## 3. Processus d'analyse technique

### Avant de proposer quoi que ce soit
1. Identifier toutes les options réalistes (minimum 3 si le sujet est structurant)
2. Evaluer chaque option sur : fiabilité, complexité, maintenabilité, coût, limites réelles
3. Donner une seule recommandation argumentée — pas un menu d'options
4. Signaler les risques avant de commencer, même si ça bloque

### Choix par défaut
- Face à simple/limité vs robuste/complexe : choisir la robuste. C'est moi qui gère la complexité.
- Estimation de complexité/temps uniquement si la tâche est significative.

### Demandes vagues ou incomplètes
- Poser des questions avant de coder, jamais après.
- Utiliser les widgets de sélection pour les questions à choix.

---

## 4. Standards de code

### Validation avant génération
- Tester JS avec vm.runInNewContext sans nettoyage — simuler le navigateur exactement.
- Vérifier les accents dans strings JS simples — remplacer par unicode (\u00e9 etc.).
- Vérifier qu'aucune fonction n'a perdu son keyword function après str_replace.
- Vérifier les doublons de déclaration après chaque modification.
- Vérifier la version en ligne AVANT de générer — incrémenter depuis la version déployée réelle.

### Versioning
- Incrémenter depuis la version déployée réelle — toujours vérifier en ligne avant.
- Mettre à jour CHANGELOG.md à chaque génération.

### Dette technique
- Si le code accumule des correctifs sur correctifs, le signaler et proposer une refonte partielle.

---

## 5. Architecture — LUMIIA Workspace

- URL : https://i-immersion.github.io/lumiia-workspace/
- Repo : https://github.com/i-immersion/lumiia-workspace
- Firebase : projet lumiia-live, Realtime DB europe-west1
- Déploiement : deployer.command (double-clic) — fait git add -A (tous les fichiers)
- Fichier de travail : /home/claude/lumiia-notes.html (copié depuis project_knowledge)

### Stack
- HTML/CSS/JS vanilla, module ES6, Firebase Realtime DB
- Pas de framework, pas de build step
- 3 utilisateurs : Emmanuel (admin), Aurélie, Marion

### Firebase structure
- /workspace/items — notes, todos, xpress
- /workspace/projects — projets avec sous-catégories
- /workspace/prospects — fiches prospects CRM

### Décisions techniques retenues
- Notifications : FCM retenu. Google Calendar et Service Worker abandonnés.
- Projets : Firebase /workspace/projects (pas localStorage)
- Dates : localDateStr(date) pour éviter décalage UTC/local
- Catégories : globales si pas de projet, sous-catégories de projet sinon

### A implémenter
- FCM : Cloud Function Firebase + enregistrement token par appareil
- Supprimer le code Google Calendar des Xpress

---

## 6. Fichiers de référence dans le Projet

- CHANGELOG.md — historique version par version
- DEVLOG.md — bugs récurrents, tentatives échouées, décisions avec contexte
- index.html — code source actuel (synchronisé depuis GitHub)

Toujours lire DEVLOG avant de toucher au code pour ne pas répéter les erreurs passées.
